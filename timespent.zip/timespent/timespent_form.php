<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * @package    report_timespent
 * @copyright  2018 Web Era Technology Pvt. Ltd.
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
 
defined('MOODLE_INTERNAL') || die();

require_once($CFG->libdir . '/formslib.php'); 

class report_timespent_form extends moodleform {
     
      public function definition() {
        global $CFG;
        global $DB;
        global $PAGE;
        global $COURSE;
        global $OUTPUT;

        $mform = $this->_form;
           
         //get course
		$courses=$DB->get_records_sql("select id, fullname, shortname from mdl_course where category<>0");
        
        $enrolledCourses=array();  
        $enrolledCourses["Select"]=null;
        
        $context = context_course::instance($COURSE->id);
        //var_dump($COURSE->id);die();
        // if(!has_capability('report/accessanalytics:viewreport', $context))
        if (!is_siteadmin())
        {   
            foreach($courses as $course){

                    //get course enrollment status of a user
                    $isEnroll=$this->getEnrollment($course);

                    if($isEnroll==1)
                        //array_push($enrolledCourses,$course);
                        $enrolledCourses[$course->id]=$course->fullname;

                }//foreach
 
        }//for
        else  
        {
           foreach($courses as $course){
		  				
		  		$enrolledCourses[$course->id]=$course->fullname;
           }//foreach 
        
        }//else    
        
       /* //select option
        $selectCourses=$mform->addElement('select', 
                           'option', 
                            get_string('selectcategory', 'report_timespent'),
                            $enrolledCourses
                          );
        //$selectCourses->setMultiple(true);
          
        
        $mform->setDefault('option', "Select");  
        $courseid = optional_param('courseid', 0, PARAM_INT);
          
        if($courseid!=0)
            $mform->setDefault('option', $courseid);  
*/          
        $searchareas = $enrolledCourses;  
        
        $areanames = array();                                                                                                       
        foreach ($searchareas as $id => $searcharea) {                                                                         
           $areanames[$id] = $searcharea;                                                
        }                                                                                                                           
        $options = array(                                                                                                           
            //'multiple' => false, 
             
            'multiple' => true,     
        );         
        $mform->addElement('autocomplete', 'courseid', get_string('selectcategory', 'report_timespent'), $areanames, $options);
    
        //$mform->addElement('html',$OUTPUT->paging_bar(25, 1, 5, ""), '', '');
        //print the table content
        // $mform->addElement('html', $content);
      
          
       /* User Profile Fields Configuration  */
           
          $userProfileFields=$DB->get_records_sql("select * from {user_info_field}");
          //print_r($userProfileFields);die();
          foreach($userProfileFields as $userProfileField){
               
              $dataType=$userProfileField->datatype;
              switch($dataType){
                  
                  case "menu":
                      
                       $menus = explode("\n", $userProfileField->param1);
                       $resMenus=array();
                       $resMenus['choose']='choose...';
                       foreach($menus as $menu){
                              $resMenus[$menu]=$menu;
                        }
              
                      
                      $selectMenu=$mform->addElement('select', 
                            'menu'.$userProfileField->id, 
                            $userProfileField->name,
                            $resMenus
                          );
                      break;
                  case "checkbox":
                       
                      break;
                  case "datetime":  
                    $mform->addElement('static', 'spacer', '<h6 style="color:green"><b>'.$userProfileField->name.':</b></h6>', '');
                      
                      $mform->addElement('advcheckbox','checkbox'.'-'.$userProfileField->name.'-'.$userProfileField->id,'Filter By '.$userProfileField->name, 'Filter By '.$userProfileField->name, array('group' => 1), array(0, 1));
                      
                       $mform->addElement('date_selector', 'startdate'.$userProfileField->id, get_string('startdate', 'report_timespent'));
          
                       $mform->addElement('date_selector', 'enddate'.$userProfileField->id, get_string('enddate', 'report_timespent'));  
                    $mform->addElement('static', 'spacer','', '');
                      break;
                      
              }
              
          }
            
        $types = array();
        foreach($userProfileFields as $userProfileField){
               if($userProfileField->datatype==="checkbox"){
                    $types[$userProfileField->id] = $userProfileField->name;   
               }
           }
         
        $typeitem = array();
            foreach ($types as $key => $value) {
               
                 $typeitem[] = &$mform->createElement('advcheckbox',$key, '', $value, array('name' => $key,'group'=>1), 1);
                 $mform->setDefault("types[$key]", false);
            }
        $mform->addGroup($typeitem, 'types','Select');
        $this->add_checkbox_controller(1);
          
        
        $this->add_action_buttons($cancel = false, $submitlabel="Submit");  
        $mform->addElement('static', 'spacer', '', '');
}
    
  
  public function validation($data, $files) {
        global $CFG, $DB, $USER;
        
        if($data['courseid']==''){
              $errors['spacer'] = get_string('selectcategory', 'report_timespent');
         return $errors;
        }
        $errors= array();
        $errors = parent::validation($data, $files);
          
        /*if($data['courseid']==='Select'){
            $errors['spacer'] = get_string('selectcategory', 'report_timespent');
              return $errors;
        }*/
       
      
        return $errors;
    }
}


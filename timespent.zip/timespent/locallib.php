<?php


function getTimeSpentOnActivity($userId,$activityId){
    global $DB; 
    //get course
     $records=$DB->get_records_sql("SELECT id,target,action,contextinstanceid,timecreated FROM {logstore_standard_log} WHERE userid=$userId ORDER BY id ASC"); 
       
    $logs=array();
    foreach($records as $rec){
        array_push($logs,$rec);
    }
        
    $sumOfInterval=array();
    $lastRecordedTime=null;
    $length=sizeof($logs);
    $flag=false; 
        
    for($i=0; $i<=$length; $i++){
          
        
        //if the user is sitting ideal in a activity then its time won't be calculated.
        if($logs[$i]->contextinstanceid==$activityId && $i==$length-1){
             array_push($sumOfInterval,
                               timeCalculation(
                                                        $logs[$i]->timecreated,
                                                        $logs[$i]->timecreated)
                                );
            break;
        }
        
           if($logs[$i]->contextinstanceid==$activityId && $logs[$i+1]->contextinstanceid!=$activityId){
               
                 if($flag!=true){
                    array_push($sumOfInterval,
                               timeCalculation(
                                                        $logs[$i]->timecreated,
                                                        $logs[$i+1]->timecreated)
                                );
                    //calculate the time interval by taking logs[i]->timecreated as Start Time
                    //add the result of time interval to $sumOfInterval
                }else{
                   
                     //login check
                     if($logs[$i+1]->action=="loggedin"){
                          array_push($sumOfInterval,timeCalculation($lastRecordedTime,$logs[$i]->timecreated)); 
                     }else{
                        //array_push($sumOfInterval,$lastRecordedTime."hello");
                        array_push($sumOfInterval,timeCalculation($lastRecordedTime,$logs[$i+1]->timecreated));
                     }
                    //here lastRecordedTime will become a Start Time 
                    //calculate the time interval by taking $lastRecordedTime as Start Time
                    //here end time will be $logs[$i+1]->timecreated
                    //add the result of time interval to $sumOfInterval
                     
                    $lastRecordedTime=null;
                    $flag=false; 
                }//else
			 
                }else if($logs[$i]->contextinstanceid==$activityId && $logs[$i+1]->contextinstanceid==$activityId){
                    if($lastRecordedTime==null){
                        $lastRecordedTime=$logs[$i]->timecreated;
				        $flag=true;
                    }
			 continue; 
           }//else-if
        }//foreach
        
       //$dateTime  = "2003-03-03 03:06:18";
       //print_r(timeFormating($dateTime));die();
        
        //print_r($sumOfInterval);die();
        $timeInterval="2000-01-01 00:00:00";
        foreach($sumOfInterval as $key => $value){
              $date = new DateTime($timeInterval);
              $date->add(new DateInterval($value));
              $timeInterval=$date->format('Y-m-d H:i:s');
        }
        
      
		 //print_r($timeInterval);die();
		 return timeFormating($timeInterval);
}
    
    
  function timeCalculation($startTimeInSec,$EndTimeInSec){
    
        $startTime=date('Y-m-d H:i:s', $startTimeInSec);
        $EndTime=date('Y-m-d H:i:s', $EndTimeInSec);

        $datetime1 = new DateTime($startTime);//start time
        $datetime2 = new DateTime($EndTime);//end time
        $interval = $datetime1->diff($datetime2);
        //return $interval->format('%Y years %m months %d days %H hours %i minutes %s seconds');
        //return $interval->format('%Y-%m-%d %H:%i:%s');
        //P8Y5M5DT1H3M2S
         
        return $interval->format('P%YY%mM%dDT%HH%iM%sS');
        
    }
    
  function timeFormating($dateTime){
          
        //$dateTime  = "2003-01-01 00:06:18";
        $pieces = explode(" ", $dateTime);
        $years=$pieces[0];

        $ymd = explode("-", $years);
        $year=$ymd[0];  
        $months=$ymd[1]-1;  
        $day=$ymd[2]-1;  

        $noOfMonths=0;
        for($i=$months; $i>0; $i--)
            $noOfMonths++;

        $days=0;
        for($i=$day; $i>0; $i--)
            $days++;

        $noOfYears=$years-2000;
 
        $timestamp=$pieces[1];  
        $hts = explode(":", $timestamp);
        $hour=$hts[0];
        $min=$hts[1];
        $sec=$hts[2];

        $finalDate="";
        
        if($noOfYears!=0){
           $finalDate.=$noOfYears." Year ";
        }
        
         if($noOfMonths!=0){
           $finalDate.=$noOfMonths." Months ";
        }
        
         if($days!=0){
           $finalDate.=$days." Days ";
        }
         
       
        
        if($hour!=0){
              $finalDate.=$hour." Hours ";
        }
        
        $finalDate.=$min." Min ".$sec." Sec";
        
        return $finalDate; 
}

function getActivitiesNcolspan($courseId){
			$activities=get_array_of_activities($courseId);
			
			$visibleActivities=new ArrayObject();
			foreach($activities as $activity){
                //print_r($activities);
				if($activity->visible==1 && $activity->deletioninprogress==0){
				//if($activity->visible==1){
					$visibleActivities->append($activity);
				}
			}
			$count=count($visibleActivities);
			return array($visibleActivities,$count);
}

function calculation($offset,$sqlConditons='',$finalSqlCondition,$isDownloading="no",$custom=false){
    
    global $DB;
     $courselist=implode(',',$custom);
    //get user
   /* $users=$DB->get_records_sql("

                SELECT u.id as userid, c.id AS id, c.fullname, u.username, u.firstname, u.lastname, u.email,u.id
                FROM mdl_role_assignments ra, mdl_user u, mdl_course c, mdl_context cxt
                WHERE ra.userid = u.id
                AND ra.contextid = cxt.id
                AND cxt.contextlevel =50
                AND cxt.instanceid = c.id
                AND c.id =9
                AND (roleid =5 OR roleid=3)
                limit $offset,10
            ");*/
    
    /* $users=$DB->get_records_sql("

                SELECT u.id as userid, u.username, u.firstname, u.lastname, u.email,u.id FROM
                mdl_user u
                limit $offset,10
            ");*/
            
   /* if($isDownloading=="no"){
        print_r("working");die();
    }else{
        print_r("not working");die();
    }*/
    
    /* if($finalSqlCondition!="")
         $prepareSQL="SELECT u.id as userid, u.username, u.firstname, u.lastname, u.email,u.id FROM mdl_user u 
                WHERE u.id IN(SELECT userid FROM mdl_user_info_data WHERE $finalSqlCondition)"." limit $offset,2";
    else
         $prepareSQL="SELECT u.id as userid, u.username, u.firstname, u.lastname, u.email,u.id FROM mdl_user u   limit $offset,2";*/
     
    $prepareSQL="";
   
     if($finalSqlCondition!="" && $isDownloading=='no'){
         echo "No";
         $prepareSQL= "SELECT u.id,u.firstname,u.lastname,u.email,u.idnumber,
                c.id as courseid,c.fullname as coursename, c.fullname,
                ue.timecreated       
                FROM {course} AS c
                JOIN {enrol} AS e ON c.id = e.courseid 
                JOIN {user_enrolments} AS ue ON ue.enrolid = e.id
                JOIN {user} AS u ON u.id = ue.userid
                
                
                WHERE c.id IN($courselist) AND u.deleted=0 AND u.suspended=0";
         // $prepareSQL="SELECT u.id as userid, u.username, u.firstname, u.lastname, u.email,u.id FROM mdl_user u 
         //        WHERE u.id IN(SELECT userid FROM mdl_user_info_data WHERE $finalSqlCondition)"." limit $offset,2";
         
     }else if($finalSqlCondition!="" && $isDownloading=='yes'){
         
         $prepareSQL= "SELECT u.id,u.firstname,u.lastname,u.email,u.idnumber,
                c.id as courseid,c.fullname as coursename, c.fullname,
                ue.timecreated       
                FROM {course} AS c
                JOIN {enrol} AS e ON c.id = e.courseid 
                JOIN {user_enrolments} AS ue ON ue.enrolid = e.id
                JOIN {user} AS u ON u.id = ue.userid
                
                
                WHERE c.id IN($courselist) AND u.deleted=0 AND u.suspended=0";
         // $prepareSQL="SELECT u.id as userid, u.username, u.firstname, u.lastname, u.email,u.id FROM mdl_user u 
         //        WHERE u.id IN(SELECT userid FROM mdl_user_info_data WHERE $finalSqlCondition)";
     
     }
    
     if($finalSqlCondition=="" && $isDownloading=='no'){
         // echo "No2222";
         
         

          $prepareSQL= "SELECT u.id,u.firstname,u.lastname,u.email,u.idnumber,
                c.id as courseid,c.fullname as coursename, c.fullname,
                ue.timecreated       
                FROM {course} AS c
                JOIN {enrol} AS e ON c.id = e.courseid 
                JOIN {user_enrolments} AS ue ON ue.enrolid = e.id
                JOIN {user} AS u ON u.id = ue.userid
                
                
                WHERE c.id IN($courselist) AND u.deleted=0 AND u.suspended=0";
          // $prepareSQL="SELECT u.id as userid, u.username, u.firstname, u.lastname, u.email,u.id FROM mdl_user u   limit $offset,2";
     }else if($finalSqlCondition=="" && $isDownloading=='yes'){
        echo "No3333";
        $prepareSQL= "SELECT u.id,u.firstname,u.lastname,u.email,u.idnumber,
                c.id as courseid,c.fullname as coursename, c.fullname,
                ue.timecreated       
                FROM {course} AS c
                JOIN {enrol} AS e ON c.id = e.courseid 
                JOIN {user_enrolments} AS ue ON ue.enrolid = e.id
                JOIN {user} AS u ON u.id = ue.userid
                
                
                WHERE c.id IN($courselist) AND u.deleted=0 AND u.suspended=0";
         // $prepareSQL="SELECT u.id as userid, u.username, u.firstname, u.lastname, u.email,u.id FROM mdl_user u";
     }
    
    
   /* if($isDownloading=="yes")
        $prepareSQL="SELECT u.id as userid, u.username, u.firstname, u.lastname, u.email,u.id FROM mdl_user u 
                WHERE u.id IN(SELECT userid FROM mdl_user_info_data WHERE $finalSqlCondition)";
    else
         $prepareSQL="SELECT u.id as userid, u.username, u.firstname, u.lastname, u.email,u.id FROM mdl_user u";
     
    */
    
    
    //echo $prepareSQL;
    //print_r($prepareSQL);die();
         if($prepareSQL){
$users=$DB->get_records_sql($prepareSQL);
         }
    
  //print_object($users);   
    
     if(count($users)==0){
         return null;
     }
    
       //print_r($sqlConditons);die();   
        $courses=$DB->get_records_sql("select id, fullname, shortname from mdl_course where category<>0 AND $sqlConditons");
     
            //adding a div for scrolling effect in a table
			$htmlContent ="<div>";
			
			$htmlContent .="<table  id='studentlist'>
									<thead><tr>
										<th rowspan=2>Username</th>
                                        <th rowspan=2>Course</th>
									"; 
        
            foreach($courses as $course){
						
                        $span=getActivitiesNcolspan($course->id)[1]*2;
            //             $htmlContent .="
												// <th colspan=".$span.">".$course->fullname."</th>";  
                     
				}
            
              
        $htmlContent .="<tr>";
         
        
				foreach($courses as $course){	
                       
							//activity heading fetching loop starts here
							foreach(getActivitiesNcolspan($course->id)[0] as $activity){
								$htmlContent .="<th>"
															.$activity->name.
														"</th>";
                                 $htmlContent .="<th>Time Spent</th>";
                  
							}
               
					}//foreach	
					
				$htmlContent .="</tr></thead>";
         
            
            foreach($users as $user){
					$htmlContent .="<tbody><tr> 
												<td>".$user->firstname."</td>
                                                <td>".$user->coursename."</td>
											";
                foreach($courses as $course){
						 
                        $context = context_course::instance($course->id);
						$isEnroll=is_enrolled($context,$user->id, '', true);
						
							 
						
                        //put the activity from the list of activities and fetch the value from it.
						foreach(getActivitiesNcolspan($course->id)[0] as $activity){
						$courseStatus=null;
                             
                              /* $courseStatus=$DB->get_records_sql("select completionstate from mdl_course_modules_completion where coursemoduleid=".$activity->cm." and userid=".$user->id.""); */ 
                            
                       
                            $courseLogStatus=$DB->get_records_sql("select id from mdl_logstore_standard_log where contextinstanceid=".$activity->cm." and userid=".$user->id."");
                            
                             $courseStatus=$DB->get_records_sql("select completionstate from mdl_course_modules_completion where coursemoduleid=".$activity->cm." and userid=".$user->id."");
                    if($isEnroll==1){    
                            if( count( $courseLogStatus ) == 0 ){
                                $htmlContent .="<td align=center>Not Attempted</td>";  
                                  $htmlContent .="<td align=center> N.A </td>";
							 }
                    }else {
                         $htmlContent .="<td align=center>-</td>"; 
                    }
                            
                        if($isEnroll==1){        
                            if( count( $courseLogStatus ) != 0 ){
                                $htmlContent .="<td align=center>Attempted</td>"; 
                                try{
                                     $htmlContent .=
                                      "<td align=center>".getTimeSpentOnActivity($user->id,$activity->cm)."</td>";
                                }catch(Exception $e){
                                     $htmlContent .=
                                      "<td align=center>Contact IT Team</td>";
                                }
                                 
				            }
                         }else {
                            $htmlContent .="<td align=center>-</td>"; 
                        }     
                            
                            if( count( $courseStatus ) == 0 ){
                                 
                            }
							else
							{
								 
							/*  print the msg based on completion status.
								 * 0. Not Completed
								 * 1. Completed 
								 * 2. Complete Pass
								 * 3. Complete Fail
							*/
								$completionState=null;
								foreach($courseStatus as $completionState){
									$completionState =$completionState->completionstate;
								}
								  
								switch ($completionState) {
									case 0:
										 
										$htmlContent .="
													<td align=center>Not Completed</td>";	
                                        try{
                                             $htmlContent .=
                                              "<td align=center>".getTimeSpentOnActivity($user->id,$activity->cm)."</td>";
                                        }catch(Exception $e){
                                             $htmlContent .=
                                              "<td align=center>N.A</td>";
                                        }
								  
										break;
									case 1:
								  		$htmlContent .="
														<td align=center>Completed</td>";	
                                        try{
                                             $htmlContent .=
                                              "<td align=center>".getTimeSpentOnActivity($user->id,$activity->cm)."</td>";
                                        }catch(Exception $e){
                                             $htmlContent .=
                                              "<td align=center>N.A</td>";
                                        }
                                        break;
									case 2:
									 	$htmlContent .="
														<td align=center>Complete Pass</td>";	
                                        try{
                                             $htmlContent .=
                                              "<td align=center>".getTimeSpentOnActivity($user->id,$activity->cm)."</td>";
                                        }catch(Exception $e){
                                             $htmlContent .=
                                              "<td align=center>N.A</td>";
                                        }
									  
										break;
									case 3:
									 
											$htmlContent .="
														<td align=center>Complete fail</td>";
                                        try{
                                             $htmlContent .=
                                              "<td align=center>".getTimeSpentOnActivity($user->id,$activity->cm)."</td>";
                                        }catch(Exception $e){
                                             $htmlContent .=
                                              "<th align=center>N.A</th>";
                                        }
											break;
										
									default:
										$htmlContent .="
												<td align=center>Contact Admin</td>";
                                          $htmlContent .="<td align=center>N.A</td>";
								}
								
							}//if-else
                         
						  }//foreach	
                        	 
                        }//foreach
                }//foreach
         
            
	 
        $htmlContent .="</tbody></table>";
				
        $htmlContent .="</div>";
    
        return $htmlContent;
}


 
    
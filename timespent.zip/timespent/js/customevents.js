function togglecostcenter(data,id){
	// alert(data);
	if(data){
		var event = 'hide';
	}else{
		var event = 'show';
	}
	// alert('done');
	$.ajax({
		method: "GET",
        dataType: "json",
        url:M.cfg.wwwroot +"/local/costcenter/ajax.php?event="+event+"&id="+id,
        success:function(resp){
        	// alert('done');
        	location.reload();
        }
	});
}

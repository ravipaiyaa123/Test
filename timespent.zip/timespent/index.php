<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * @package    report_timespent
 * @copyright  2018 Web Era Technology Pvt. Ltd.
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
  
require_once(dirname(__FILE__) . '/../../config.php');
require_once(dirname(__FILE__) . '/locallib.php');
require_once(dirname(__FILE__) . '/timespent_form.php');
require_once(dirname(__FILE__) . '/testform.php');
require_once($CFG->libdir . '/adminlib.php');
require_once($CFG->libdir.'/pdflib.php');
require_once ($CFG->libdir . '/tcpdf/tcpdf.php');

global $DB;

$PAGE->requires->jquery();
$PAGE->requires->css('/report/timespent/css/jquery.dataTables.css');
$PAGE->requires->js('/report/timespent/js/jquery.dataTables.min.js', true);
$PAGE->requires->js('/report/timespent/js/select2.full.js', true);
$PAGE->requires->css('/report/timespent/css/select2.min.css');
//$PAGE->requires->css('/report/timespent/css/buttons.dataTables.css');
// Start the page.
admin_externalpage_setup('report_timespent');

echo $OUTPUT->header().
    $OUTPUT->heading(get_string('heading', 'report_timespent'));
 
$offset = optional_param('page', 0, PARAM_INT);
$offset1 = optional_param('page', 0, PARAM_INT);
$sqlConditons = optional_param('courseid', 0, PARAM_RAW);
 

$mform =new report_timespent_form();


/*
//$mform1 =new report_timespent_form1();
if ($data = $mform1->get_data()) {
    
       ob_clean();
    $pdf = new pdf();
    $pdf->AddPage();
    $pdf->WriteHTML('<p>This is an example</p>');
    $pdf->Output('output.pdf', 'F');
     //redirect($CFG->wwwroot.'/report/timespent/dummyfile.php');
   
   // $baseurl = new moodle_url('/report/timespent/dummyfilde.php');
   
   
    
}*/

$mform->display();
//$mform1->display();
$htmlContent="";


/*

$students = get_enrolled_users(context_course::instance(9));
print_r($students);die();
*/

 
if ($data = $mform->get_data()) {
   
    $newData=$data;
   
    $menuArray=array(); 
    $dateArray=array();
    $checkBoxArr=array();
    $filterDateRange=array();
   
    require_once(dirname(__FILE__) . '/template.php');
     
    foreach($data as $key=>$values){
        
        if(substr($key,0,8)=="checkbox"){
            $filterCheck=explode('-',$key);
            
             $checkbox=new CheckBox;
             
             $checkbox->setId($filterCheck[2]);
                    if($values=="")
                        $checkbox->setValue(0);
                    else
                       $checkbox->setValue($values); 
            array_push($filterDateRange,$checkbox);
            //print_r($filterCheck);die();
        }
         $a = $key;
         $len=strlen($a);
         $finalKey ="";
       
        if($key=="types"){
            $finalKey ="types";
        }
        
        if(substr($a,0,9)=="startdate"){
            $finalKey ="startdate";
        }
        
        if(substr($a,0,7)=="enddate"){
            $finalKey ="enddate";
        }
         
        if(substr($a,0,4)=="menu"){
            $finalKey ="menu";
        }
     
        switch($finalKey)
        {
            case "menu":
                
                $str=$key;
                $menuRequiredKey=explode('menu',$str);
                
                $menu = new Menus;
                
                if($values!="choose"){
                    $menu->setId($menuRequiredKey[1]);
                    $menu->setvalue($values);
                    array_push($menuArray,$menu);
                }
                break;
            case "startdate":
                 $str=$key;
                 $dateRequiredKey=explode('startdate',$str);
                 
                 $dateTime=new DateTimee;
                 $dateTime->setId($dateRequiredKey[1]);
                 $dateTime->setStartDate($values);
                
                 array_push($dateArray,$dateTime);
                 
                break;
                
            case "enddate":  
                 $str=$key;
              
                $dateRequiredKey=explode('enddate',$str);
                 
                foreach($dateArray as $obj){
                   if($obj->getId()==$dateRequiredKey[1]){
                       $obj->setEndDate($values);
                   }
                }
                 
                break;
                
            case "types":
                //for checkbox
                
                foreach($data->types as $key => $value){
                    $checkbox=new CheckBox;
                    $checkbox->setId($key);
                    if($value=="")
                        $checkbox->setValue(0);
                    else
                        $checkbox->setValue($value);
                    if($value!="")
                    array_push($checkBoxArr,$checkbox);
                }
                break;
        }
    }//foreach
    
    
    //query construction
    
    $menuStr="";
   
    $numItems = count($menuArray);
    $i = 0;
    foreach($menuArray as $data){
      // \"red\"
        $menuStr.=" fieldid=".$data->getId()." AND ";
        $value=$data->getValue();
        $menuStr.="data=\"$value\"";
         
         if(++$i === $numItems) {
             
         }else{
             $menuStr.=" OR ";
         }   
    }
    //print_r($menuStr);die();
    
 ////////////////////////////////////////// 
    $finalFilteredDateArray=array();
    
    //filter the date fields
    foreach($filterDateRange as $range){
        $id=$range->getId();
       
    if($range->getValue()==1)
        foreach($dateArray as $dt){
            if($dt->getId()==$id){
                array_push($finalFilteredDateArray,$dt);
            }
        }//inner - foreach
    }//foreach
////////////////////////////////////////////
    
  
    $dateTime="";
    
    
    $numItems = count($finalFilteredDateArray);
    $i = 0;
    foreach($finalFilteredDateArray as $data){
        $dateTime.=" fieldid=".$data->getId()." AND ";
        $dateTime.="data >=".$data->getStartDate()." AND ";
        $dateTime.="data <=".$data->getEndDate();
        
        if(++$i === $numItems) {
             
         }else{
             $dateTime.=" OR ";
         }   
    }
    
    
    //print_r($finalFilteredDateArray);die();
   /* SELECT userid FROM `mdl_user_info_data` WHERE fieldid=2 AND data >=1536210800 AND data <=1569597600 */
    
    $checkBoxStr="";
    $numItems = count($checkBoxArr);
    $i = 0;
    foreach($checkBoxArr as $data){
        $checkBoxStr.=" fieldid=".$data->getId()." AND ";
        $checkBoxStr.="data=".$data->getValue();
         if(++$i === $numItems) {
             
         }else{
             $checkBoxStr.=" OR ";
         }    
    }
    
    
    
   /* Array ( [0] => CheckBox Object ( [id] => 1 [value] => 0 ) [1] => CheckBox Object ( [id] => 2 [value] => 0 ) [2] => CheckBox Object ( [id] => [value] => 0 ) )
    */
    
   /* Array ( [0] => DateTimee Object ( [id] => 1 [startDate] => 1536184800 [endDate] => 1536184800 ) [1] => DateTimee Object ( [id] => 2 [startDate] => 1536184800 [endDate] => 1536184800 ) )
    */
    //join all the filter conditions
    $finalSqlCondition="";
    
    if(strlen($menuStr)>0 && strlen($dateTime)>0 && strlen($checkBoxStr)>0)
    {
       $finalSqlCondition=$menuStr.' OR '.$dateTime.' OR '.$checkBoxStr; 
    }
    if(strlen($menuStr)>0 && strlen($dateTime)>0 && strlen($checkBoxStr)==0)
    {
         $finalSqlCondition=$menuStr.' OR '.$dateTime; 
    }
    if(strlen($menuStr)>0 && strlen($dateTime)==0 && strlen($checkBoxStr)==0)
    {
        $finalSqlCondition=$menuStr;
    }
    if(strlen($menuStr)==0 && strlen($dateTime)==0 && strlen($checkBoxStr)==0)
    {
        $finalSqlCondition="";
    }
    if(strlen($menuStr)>0 && strlen($dateTime)==0 && strlen($checkBoxStr)>0)
    {
        $finalSqlCondition=$menuStr.' OR '.$checkBoxStr; 
    }
    if(strlen($menuStr)==0 && strlen($dateTime)>0 && strlen($checkBoxStr)>0)
    {
        $finalSqlCondition=$dateTime.' OR '.$checkBoxStr; 
    }
    if(strlen($menuStr)==0 && strlen($dateTime)==0 && strlen($checkBoxStr)>0)
    {
        $finalSqlCondition=$checkBoxStr; 
    }
    if(strlen($menuStr)==0 && strlen($dateTime)>0 && strlen($checkBoxStr)>0)
    {
        $finalSqlCondition=$dateTime.' OR '.$checkBoxStr; 
    }
    if(strlen($menuStr)==0 && strlen($dateTime)>0 && strlen($checkBoxStr)==0)
    {
        $finalSqlCondition=$dateTime; 
    }
   
    //print_r($finalSqlCondition);die();
    
  
    
    $courseId=null;
    
    foreach($data as $key=>$value){
        if($key==='courseid')
            $courseId=$value;
    }
  $courseId=4;
    //for multiple selection
    $courseId=null;
    $couseIdLists=array();
    $flag=1;
    $sqlConditons="";
    $custom=$newData->courseid;
    foreach($newData->courseid as $key=>$values){
         
             $strTemp = trim($values);
         //print_r($strTemp);
            if(strlen($strTemp) > 0){
                if($flag==1){
                    $sqlConditons.='id='.$values." ";
                    //array_push($couseIdLists,'id='.$value);
                    $flag=0;
                }else{
                     $sqlConditons.='OR id='.$values." ";
                     //array_push($couseIdLists,'OR id='.$value);
                }
            }      
    }
    
     $finalsqlcondition = optional_param('finalsqlcondition', 0, PARAM_RAW);
 
     if($finalSqlCondition!="")
         $prepareSQL="SELECT u.id as userid, u.username, u.firstname, u.lastname, u.email,u.id FROM mdl_user u 
                WHERE u.id IN(SELECT userid FROM mdl_user_info_data WHERE $finalSqlCondition)"." limit $offset,2";
    else
         $prepareSQL="SELECT u.id as userid, u.username, u.firstname, u.lastname, u.email,u.id FROM mdl_user u   limit $offset,2";
    
    if($finalSqlCondition!="")
        $totalUser=$DB->get_records_sql($prepareSQL); 
    else
        $totalUser=$DB->get_records_sql("SELECT u.id as userid, u.username, u.firstname, u.lastname, u.email,u.id FROM mdl_user u"); 
    
    /* $totalUser=$DB->get_records_sql("

                SELECT u.id as userid, u.username, u.firstname, u.lastname, u.email,u.id FROM
                mdl_user u
            ");*/
    
     
      //get user
        $users=$DB->get_records_sql($prepareSQL);
       
    $baseurl = new moodle_url('/report/timespent/index.php', array('courseid'=>$sqlConditons,'$finalsqlcondition'=> $finalSqlCondition));
    $perpage=2;
    //echo $OUTPUT->paging_bar(count($totalUser), 0, $perpage, $baseurl);
    //echo $OUTPUT->paging_bar(count($results), $page, $perpage, $baseurl);
    
            if(count($users)!=0){
            
                  $htmlContent.=calculation($offset,$sqlConditons,$finalSqlCondition,$isDownloading="no",$custom);
            }
            else
            {
                $courses=$DB->get_records_sql("select id, fullname, shortname from mdl_course where id=9");
                foreach($courses as $course)
                    $htmlContent .="<h5>No Student Enrolled To <span style='color:blue'>$course->fullname.<span></h5>"; 
            }
}
else
{
        
   /* $totalUser=$DB->get_records_sql("

                SELECT u.id as userid, c.id AS id, c.fullname, u.username, u.firstname, u.lastname, u.email,u.id
                FROM mdl_role_assignments ra, mdl_user u, mdl_course c, mdl_context cxt
                WHERE ra.userid = u.id
                AND ra.contextid = cxt.id
                AND cxt.contextlevel =50
                AND cxt.instanceid = c.id
                AND c.id =9
                AND (roleid =5 OR roleid=3)
                 
            ");*/
     $finalsqlcondition = optional_param('finalsqlcondition', 0, PARAM_RAW);
 
     if($finalSqlCondition!="")
         $prepareSQL="SELECT u.id as userid, u.username, u.firstname, u.lastname, u.email,u.id FROM mdl_user u 
                WHERE u.id IN(SELECT userid FROM mdl_user_info_data WHERE $finalSqlCondition)"." limit $offset,2";
    else
         $prepareSQL="SELECT u.id as userid, u.username, u.firstname, u.lastname, u.email,u.id FROM mdl_user u   limit $offset,2";
    
    
      if($finalSqlCondition!="")
        $totalUser=$DB->get_records_sql($prepareSQL); 
    else
        $totalUser=$DB->get_records_sql("SELECT u.id as userid, u.username, u.firstname, u.lastname, u.email,u.id FROM mdl_user u"); 
    
    
   // $totalUser=$DB->get_records_sql($prepareSQL);

    if($sqlConditons!="0"){

    $offset=$offset*2;

        $baseurl = new moodle_url('/report/timespent/index.php', array('courseid'=>$sqlConditons,'$finalsqlcondition'=> $finalSqlCondition));

        $perpage=2;
       // echo $OUTPUT->paging_bar(count($totalUser), $offset1, $perpage, $baseurl);
        //echo $OUTPUT->paging_bar(count($results), $page, $perpage, $baseurl);
        $htmlContent.=calculation($offset,$sqlConditons,$finalsqlcondition,$isDownloading="no",$custom);

                if($htmlContent==null){

                    $courses=$DB->get_records_sql("select id, fullname, shortname from mdl_course where id=9");
                    foreach($courses as $course)
                        $htmlContent .="<h5>No Student Enrolled To <span style='color:blue'>$course->fullname.<span></h5>"; 
                }



    }
}
if(strlen($htmlContent)>0){ 
echo ' 
<a id="dlink"  style="display:none;"></a>
    <a href="#" onclick="tableToExcel(`studentlist`, `W3C Example Table`, `MyFile.xls`)">Download Excel</a><br><br>';
}

echo $htmlContent;
    /***SELECT u.id as userid,u.firstname,u.lastname,u.email,u.idnumber,
				c.id as courseid,c.fullname as coursename, c.fullname,
				ue.timecreated		 
		        FROM {course} AS c
                JOIN {enrol} AS e ON c.id = e.courseid and e.enrol in('auto','manual','self')
                JOIN {user_enrolments} AS ue ON ue.enrolid = e.id
                JOIN {user} AS u ON u.id = ue.userid
                JOIN {course_completions} AS cc ON cc.course = e.courseid and cc.userid=ue.userid

                
                WHERE e.courseid={$filter_courses} AND u.deleted=0 AND u.suspended=0******/
echo '<script>


var tableToExcel = (function () {
    var uri = "data:application/vnd.ms-excel;base64,",
        template = "<html xmlns:o=`urn:schemas-microsoft-com:office:office` xmlns:x=`urn:schemas-microsoft-com:office:excel` xmlns=`http://www.w3.org/TR/REC-html40`><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head><body><table>{table}</table></body></html>",
        base64 = function (s) {
            return window.btoa(unescape(encodeURIComponent(s)))
        }, format = function (s, c) {
            return s.replace(/{(\w+)}/g, function (m, p) {
                return c[p];
            })
        }
    return function (table, name, filename) {
        if (!table.nodeType) table = document.getElementById(table)
        var ctx = {
            worksheet: name || "Worksheet",
            table: table.innerHTML
        }
   document.getElementById("dlink").href = uri + base64(format(template, ctx));
            document.getElementById("dlink").download = filename;
            document.getElementById("dlink").click();
    }
})()

</script>';											
											
	 
echo $OUTPUT->footer();
?>
<script>
$(document).ready(function(){
     $('#studentlist').DataTable();
    $(".assign_training_at").select2();
    
    $(".learningplan-assign-course").select2({
        placeholder: "Select Courses"
    });
    $( ".assign_courses_container" ).hide();
    
    //$(".learningplan-assign-users").select2({
    //    placeholder: "Select Users"
    //});
    $( ".assign_users_container" ).hide();
});

</script>